%{
Jeremiah de la Paz
UID: 405497856

Birthday Paradox

%}

clc; clear all; close all;
numPeople = 1:100;
bdayArray = zeros(1,100);
for n = 1: 100 % calculating probability for 1 - 100 people
    duplicate = 0; % number of times the array has a duplicate
    for i = 1: 3000
        bday = floor(365 * rand(n,1)) + 1;
        if length(bday) ~= length(unique(bday)) %check if the array has any duplicates
            duplicate = duplicate + 1;
        end
    end
    bdayArray(n) = 100 * duplicate / 3000;
end

figure;
scatter(numPeople, bdayArray, '*');
xlabel('number of people (n)');
ylabel('probability (%)');
title('Probablity of Shared Birthday');

            

