function x = myRand()
% Outputs:
% x: array of the random samples drawn from p(x)

y = rand(1100,1);


x = -3.*(sqrt(-y+1)-1);

