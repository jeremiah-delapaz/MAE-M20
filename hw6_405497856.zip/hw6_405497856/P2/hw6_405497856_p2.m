clc; clear all; close all;



x = linspace(0,3); % create an array of x values evenly spaced from 0 to 3
y =  -2/9.*x + (2/3); % p(x)

figure; 

% plot the histogram
histogram(myRand(), 'Normalization', 'pdf'); % calls myRand, which is already an array
hold on;
%plot p(x)
plot(x,y,'*');
xlabel('x axis');
ylabel('y axis');
title('probability density function');
hold off;