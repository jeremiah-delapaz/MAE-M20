function [winpct2, winpct3] = wincheck(n, threept,twopt,oppft,ftrbd, rbd)

%{
determine win probability for taking three point and two point

inputs:
n: number of iterations
threept: three point percentage of makes as decimal
twopt: two point percentage of makes as decimal
oppft: opponent free throw percentage as decimal
ftrbd: offensive rebound percentage as decimal
rbd: regular rebound percentage as decimal

outputs: 
winpct2: percentage of wins by taking the 2 point
winpct3: percentage of wins by taking the 3 point

%}

winct2 = 0;

%% calculate 3 point win times
% Take three
% if make three --> game ties, win pct is 50%
% if Miss three -- > lose game

threerand = rand(n,1);
madethree = rand(n,1); 
a = threerand <= threept & madethree <= 0.5;

winpct3 = 100 * sum(a)/n;


%% calcuate 2 point win percentage
for i = 1:n      
    timeLeft = 30; %seconds
    pointDifference = -3; % my teams score relative to opponents
    pos = true; %my team starts with the ball always
    while timeLeft > 0                       
        if pos % our posession 
            if rand <= twopt % make two pointer
                timeLeft = timeLeft - 5;
                pointDifference = pointDifference + 2;
                pos = false; % other teams ball and foul
            else
                pos = regRbd(rbd); % if other teams ball, foul
            end
               
        else %other teams posession
            %assume it takes no time to foul
            ft = freeThrowsMade(oppft);
            pointDifference = pointDifference - ft;
            if ft==2 % if they make both free throws, posession automatically goes back to my team
                pos = true;
            else
                % assume it is a 1 and 1, if they miss either free throw, posession goes to whoever gets rebound
                pos = ~regRbd(ftrbd); %since the other team is on offense, the posession is the opposite of the rbd function
            end   
        end
        
    end

    
    if pointDifference == 0 %if a tie by the end of regulation, game goes to ot, prob of winning is 0.5
        if rand <=0.5
            winct2 = winct2 + 1;
        end
    elseif pointDifference > 0
            winct2 = winct2 + 1;
    end
    
    
end

winpct2 =  100 * winct2 / n;
        


        
            
            
            
    
    
    

    


