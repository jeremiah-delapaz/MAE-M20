function [ft] = freeThrowsMade (oppft)
freeThrows = rand(2,1);
ft = sum(freeThrows <= oppft);