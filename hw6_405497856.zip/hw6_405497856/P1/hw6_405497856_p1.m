clc; clear all; close all;

n = 2000;
threept = 0.25;
twopt = 0.6;
oppft = 0.65;
ftrbd = 0.15;
rbd = 0.25;


[winpct2, winpct3] = wincheck(n, threept,twopt,oppft,ftrbd, rbd);

fprintf('win percentage when taking the three: %.2f%%\nwin percentage when taking the two %.2f%%', winpct3, winpct2);