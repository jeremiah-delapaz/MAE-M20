function [possession] = regRbd(rbd)
%{
returns true if the offensive team gets rebound, false if not.
%}
if rand <= rbd
    possession = true;
else
    possession = false;
end
