function [result] = M(x)
%{
input: x
output: piecewise function M(x)
%}
d = 0.2;
L = 1;
P = 1000;

M0 = (P*d * (L-d)^2 )/ L^2 ;
M1 = -(2*P*d^2*(L-d)^2) / L^3 ;
M2 = (P * d^2 * (L-d)) / L^2 ;

if x <= d
    result = M0 + (((M1 - M0) * x) / d);
else
    result = M1 + (((M2 - M1) * (x - d)) / (L-d));
end



