clc; clear all; close all;

%{
Euler Bending
Jeremiah de la Paz
UID: 405497856

%}

% define constnats
L = 1;
r = 0.08;
P = 1000;
d = 0.2;
I = pi * r ^ 4 / 4;
E = 65 * 10^9;

nodes = 10;


% discretized second derivative: f''(xi) = (f(xi+1) -2f(xi) +
% f(xi-1))/deltax^2 + O(deltax^2)
% yk+1 - 2yk + yk-1 = deltax^2 M(x) / EI


tic;

%% Initialize A Matrix (A*y = B)

A = zeros(nodes,nodes);
A(1,1) = 1;
A(end,end) = 1;

for i = 2: nodes - 1
    A(i, i -1: i+1) = [1,-2,1];
end

%% Define B Matrix

B = zeros(nodes, 1);
X = linspace(0,L, nodes);
dx = X(2) - X(1);

for i = 2: nodes - 1
    x= X(i);
    B(i) = ( dx^2 * M(x) ) / (E*I);
end


Y = A\B;

%ytheo =  2*P*d^3 * (L-d)^2 / (3*E*I * (2*d + L)^2);
ytheo =  2*P*(L-d)^3 * (L-(L-d))^2 / (3*E*I * (2*(L-d) + L)^2);

[max, index] = max(Y);

elapsedTime = toc;

fprintf('theoretical max: %e\n', ytheo);
fprintf('calculated max: %e\n', max);
fprintf('x location of calculated max %f\n', index * dx);

fprintf('percent error: %f %%', 100* ( (max-ytheo) / ytheo ) );
fprintf('elapsed time: %f \n', elapsedTime);
fprintf('%f', index * dx);


figure;
plot(X,Y, 'o-');
hold on;
plot(X, ytheo * ones(nodes,1));

title('Displacement');
xlabel('X (m)');
ylabel('Y (m)');
legend('numerical', 'theoretical');






