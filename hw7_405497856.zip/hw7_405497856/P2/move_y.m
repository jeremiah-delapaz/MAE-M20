function [new_y] = move_y(y, dir, max_y)

%{

inputs
y : current y value
dir: direction ant is traveling in
max_x: endpoint to check if ant is at edge

outputs
new_y: updated y value after moving

%}

% boundary conditions

if y == max_y && dir == 0
    new_y = 1;
elseif y == 1 && dir == 2
    new_y = max_y ;
else
    if dir == 0
        new_y = y + 1;
    elseif dir ==1
        new_y = y;
    elseif dir == 2
        new_y = y - 1;
    elseif dir == 3
        new_y = y;
    end
end


    




