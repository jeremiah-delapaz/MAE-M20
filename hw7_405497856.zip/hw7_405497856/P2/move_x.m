function [new_x] = move_x(x, dir, max_x)

%{
inputs
x : current x value
dir: direction ant is traveling in
max_x: endpoint to check if ant is at edge

outputs
new_x: updated x value after moving
%}
% boundary conditions


if x == max_x && dir == 1
    new_x = 1;
elseif x == 1 && dir == 3
    new_x = max_x ;
else
    if dir == 0
        
        new_x = x;
        
    elseif dir == 1
        
        new_x = x + 1;
        
    elseif dir == 2
        
        new_x = x;
        
    elseif dir == 3
        
        new_x = x - 1;
        
    end
end

    
