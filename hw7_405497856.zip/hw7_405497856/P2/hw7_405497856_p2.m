%{
 Langton's Ant
Jeremiah de la Paz
UID: 405497856


dir
- north = 0
- east = 1
- south = 2
- west = 3

spin 
-clockwise = 1
-cc = 0



%}
clc; clear all; close all;



num_rows = 50;
num_cols = 50;

board = zeros(num_rows, num_cols);

dir = 0; % initially facing north

% randomize start position
x = ceil(num_cols * rand);
y = ceil(num_rows * rand);
figure;


v = VideoWriter('langtonsant.avi');
open(v);
t = linspace(0,1000,2000);
portion = zeros(2000,3);




for i = 1:2000
    
    
    if board(y, x) == 0
        %turn 90  clockwise, turn the color of the square to B, moved forward
        %one unit
        
        dir = rotate(dir, 1);
        board(y, x) = 1;
        x = move_x(x, dir, num_cols);
        y = move_y(y, dir, num_rows);
        
    
    elseif board(y, x) == 1
        %turn 90  clockwise, turn the color of the square to C, moved forward one
        %unit
        
        dir = rotate(dir, 1);
        board(y, x) = 2;
        x = move_x(x, dir, num_cols);
        y = move_y(y, dir, num_rows);
    
    
    elseif board(y, x) == 2
        %turn 90  counter-clockwise, turn the color of the square to D, moved
        %forward one unit
        
        dir = rotate(dir, 0);
        board(y, x) = 3;
        x = move_x(x, dir, num_cols);
        y = move_y(y, dir, num_rows);
   
    
    elseif board(y, x) == 3
        %turn 90  counter-clockwise, turn the color of the square to A, moved
        %forward one unit
        
        dir = rotate(dir, 0);
        board(y, x) = 0;
        x = move_x(x, dir, num_cols);
        y = move_y(y, dir, num_rows);
    end
    
    for c = 1:3
        temp = find(board == c);
        portion(i, c) = sum(temp(:))/(num_cols * num_rows);
    end
    
    % Display on figure
    imagesc(board);
    set(gca,'YDir', 'normal');
    drawnow;
    
    % Write to video
    F = getframe;
    writeVideo(v,F.cdata);
    
end

v.close();
plot(t, portion(:,1));
hold on;
plot(t, portion(:,2));
plot(t, portion(:,3));


xlabel('time');
ylabel('portion of black grids');
legend('Color B', 'Color C', 'Color D');


    
    