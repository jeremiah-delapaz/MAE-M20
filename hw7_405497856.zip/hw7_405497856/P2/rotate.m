function [new_dir] = rotate(dir, spin)

%{
inputs
dir: current direction
spin: clockwise or counterclockwise
outputs:
new_dir: new direction

%}

if spin == 1 % clockwise
    if dir == 3
        new_dir = 0;
    else
        new_dir = dir + 1;
    end

else % counter clockwise
    
    if dir == 0
        new_dir = 3;
    else
        new_dir = dir - 1;
    end
    
end

