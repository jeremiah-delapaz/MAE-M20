clc; clear all; close all;


%% Load mesh Using STL Read
fprintf('Calling stlRead to load mesh...\n');
ticstart = tic;
mesh = stlRead('modifiedSphereSTL.txt');
fprintf('finished in %.3f seconds\n', toc(ticstart));


%% Load SIR parameters
N = length(mesh);
fprintf('Loading initial parameters...\n');
ticstart = tic;
load('SIRparameters.mat');
initialCondition = zeros(N,3);
initialCondition(:,1) = 1; %S
initialCondition(:,2) = 0; %I
initialCondition(:,3) = 0; %R

num_infect = numel(initialInfections);
%search through initial infections for index of initial infection
for i = 1:num_infect
    for j = 1:N
        dist = norm(mesh(j).location - initialInfections{i});
        if dist < 1e-10
            ind = j; % index of 
            break
        end
    end
    initialCondition(ind,:) = [0,1,0]; %S = 0, I = 1, R = 0; set initial infection at found index
end
fprintf('finished in %.3f seconds\n', toc(ticstart));

%% Solve Spatial SIR with RK4

fprintf('Solving Spatial SIR with RK4...\n');
ticstart = tic;
[tRK, yRK] = solveSpatialSIR(tFinal, mesh, initialCondition, ...
    alpha, beta, gamma, @RK4);
fprintf('finished in %.3f seconds\n', toc(ticstart));


%% Solve Spatial SIR with ODE45


fprintf('Solving Spatial SIR with ODE45...\n');
ticstart = tic;
[t45, y45] = solveSpatialSIR(tFinal, mesh, initialCondition, ...
    alpha, beta, gamma, @ode45);
fprintf('finished in %.3f seconds\n', toc(ticstart));


%% Call plotTimeSeries

fprintf('calling plotTimeSeries at specified coordinates...\n');
ticstart = tic;
for i = 1:numel(monitorLocations)
    plotTimeSeries(mesh, tRK, yRK, monitorLocations{i});
    
end
fprintf('finished in %.3f seconds\n', toc(ticstart));


%% Animate
animate(mesh, tRK, yRK);


%% Write to Excel

write2Excel(mesh,tRK, yRK, 'SIRData.xlsx');








