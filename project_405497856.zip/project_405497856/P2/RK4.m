function [t, y] = RK4(f, tspan, y0)
% RK4 Bogacki-Shampine method of RK4 with adaptive step size
% Inputs:
% f: function handle of f(t, y)
% tspan: the time period for simulation (should be a 1x2 array ...
%contain start time and end time)
% y0: the initial conditions for the differential equation
% Outputs:
% t: corresponding time sequence as a T x 1 vector
% y: the solution of the differential equation as a T x n matrix, ...
%where T is the number of time steps and n is the dimension of y


%% Declare variables and allot space for arrays

h = 0.1;
%N  = (tspan(end) -tspan(1))/h;
e0 = 1e-4;

t = zeros(3000,1); % will truncate later
y = [];

t0 = tspan(1);
tf = tspan(end);
t(1) = t0;
y(1,:) = y0';
tk = t(1);
yk = y(1,:)';
i = 1;
while tk < tf
    i = i+1;
    h = min(h, tf -tk);
    tkp1 = tk + h; %tkp1 is the next tk value (t _ k plus one)
    % evaluate k values using given formulas
    k1 = f(tk, yk); 
    k2 = f(tk+ (h/2) , yk + (h*k1)/2);
    k3 = f(tk + (3/4)*h , yk + (3/4)*h*k2);
    ykp1 = yk + ((2/9)*h*k1) + ((1/3)*h*k2) + ((4/9)*h*k3);
    k4 = f(tk+h,ykp1);
    z = yk + (7/24)*h*k1 + (1/4)*h*k2 + (1/3)*h*k3 + (1/8)*h*k4;
    
    y(end+1,:) = ykp1; % append to end of array
    t(i, :) = tkp1;
   
    e = norm(ykp1-z); % calculate norm
    
    h = h*(e0/e)^0.2;
    
    tk = tkp1; % update t  
    yk = ykp1; % updae y
    
end
t = t(1:i); % truncate t
end


 