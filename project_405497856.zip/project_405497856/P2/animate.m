function animate(mesh, t, X)
% animate: a function that shows the change in the ratio of susceptible,
% infected, and recovered individuals in the grid as an image.
%
% Inputs:
% mesh: an struct of mesh information of the triangulated surface
% t: the time vector
% X: an N*3*length(t) matrix, where each Nx3 matrix corresponds to
% the state of the S.I.R. system at a particular instance in time.
% This 2D matrix is repeated for each time step, making it a 3D ...
% matrix.
%
% Output: this function does not output anything.


N = length(mesh); % Number of nodes
coord = zeros(N,3);
color = zeros(size(X)); % Colors representing S, I, R


for i = 1:N
    coord(i,:) = mesh(i).location;
end

color(:,1,:) = X(:, 2, : ); %Red for infected

color(:,2,:) = X(:, 3, : ); %green for recovered

color(:,3,:) = X(:, 1, : ); %blue for susceptible

figure;

currT = 0; % current time
d = 20;
for i = 1:length(t)
    if t(i) >= currT
        % Plot
        
        pcshow(coord,color(:,:,i), 'MarkerSize', 500);
        xlabel('X');
        ylabel('Y');
        zlabel('Z');
        pause(0.1)
        currT = currT + 0.1 * d; 
    end
end


end

    



