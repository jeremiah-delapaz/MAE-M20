function [t, x] = solveSpatialSIR(tFinal, mesh, initialCondition, ...
    alpha, beta, gamma, odeSolver)
%solveSpatialSIR Solve the spatial SIR model
% Inputs:
% tFinal: end time for the simulation (assuming start is t=0)
% mesh: the underlying mesh
% initialCondition: a Nx3 matrix that sums to 1 in third dimension
% alpha, beta, gamma: model parameters
% odeSolver: a function handle for an ode45-compatible solver
% Outputs:
% t: a vector of the time-steps
% x: Nx3xlength(t) matrix representing the state vs. time


% call dynamics SIR to create function used as input in odeSolver
dSIRdt = @(t,x) dynamicsSIR(x,mesh, alpha, beta, gamma);

[t,y] = odeSolver(dSIRdt, [0,tFinal], initialCondition(:)); % solve function, using iether RK4 or ode45

nSteps = length(t); % number of time elements
N = length(mesh); % length of mesh

x = zeros(N,3, nSteps); % allovate space for x

for i = 1:nSteps
    local_sol = y(i,:); % SIR values at i-th step (array)
    reshaped_sol = reshape(local_sol, [N,3]); % Nx3 matrix
    x(:,:,i) = reshaped_sol; % Nx3 matrix at ith step
    
end



end
