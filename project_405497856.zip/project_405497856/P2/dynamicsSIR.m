function dxdt = dynamicsSIR(x, mesh, alpha, beta, gamma)
% dynamicsSIR Compute the rate of change of the model
% Inputs:
% x: vectorized state
% mesh: the underlying mesh
% alpha, beta, gamma: model parameters
% Output:
% dxdt: vectorized time derivative of state
%Here, x is a one-dimensional column vector of length 3N, and alpha,


N = length(mesh);
%x = x';
x = reshape ( x , [N , 3 ]);
derivatives = zeros(N,3);
%% iterate through length of array
for i = 1: N - 1
    
    n_i = length(mesh(i).neighbors);
    
    dist_sum = 0; % sum of euclidian distances, d(i,j)
    
    for j = 1:n_i 
        dx = mesh(mesh(i).neighbors(j)).location(1) - mesh(i).location(1); % x distance between two points
        dy = mesh(mesh(i).neighbors(j)).location(2) - mesh(i).location(2); % y distance between two points
        dz = mesh(mesh(i).neighbors(j)).location(3) - mesh(i).location(3); % z distance between two points
        dist_sum = dist_sum + (x(mesh(i).neighbors(j),2) / sqrt(dx^2 + dy^2 + dz^2)); % add I_j / euclidian distance to sum
    end
   
    
    neighborCont = (alpha / n_i ) * dist_sum; %neighbor contribution
        
    
    derivatives (i,1) = - ( beta * x(i,2)+ neighborCont ) * x(i,1); %S_i
    derivatives (i,2) = (beta * x(i,2) + neighborCont) * x(i,1) - gamma*x(i,2); %I_i
    derivatives (i,3) = gamma * x(i,2) ; %R_i
end


% vectorize derivatives
dxdt = derivatives(:);

end

