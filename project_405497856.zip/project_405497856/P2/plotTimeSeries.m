function plotTimeSeries(mesh, t, X, coord)
% plotTimeSeries: a function that plots and saves the local S.I.R ...
% distribution at spatial coordinate (x, y, z). 
% Inputs:
% mesh: an struct of mesh information of the triangulated surface
% t: a vector of time steps
% X: an N*3*length(t) matrix, where each point in the M*3 space
% corresponds to a local S.I.R. model with states whose values ...
% are between 0 and 1. This 2D matrix is repeated for each time step, ...
% making it a 3D matrix.
% coord: a 1*3 vector of local vertex's coordinate
% Outputs:
% This function has no outputs

N = length(mesh);
%% search for index of the coordinate in the mesh array
a = cell2mat({mesh.location});
a = transpose(reshape(a,[3,N])); % reshape a row wise to be able to search for coord
ind = find(ismember(a, coord, 'rows'));
%% create S, I, R arrays that are one dimensional to be able to graph against t 
S = squeeze(X(ind,1,:)); % make X a one dimensional array
I = squeeze(X(ind,2,:));
R = squeeze(X(ind,3,:));

f1 = figure;



%% Plot Susceptible
subplot(3,1,1);
plot(t,S, 'blue', 'LineWidth', 4);
title('Local Susceptible over time values at coordinate' );
xlabel('time');
ylabel('Ratio of susceptible');


%% Plot Infected
subplot(3,1,2);
plot(t,I, 'red','LineWidth', 4);
title('Local Infected over time values at coordinate');
xlabel('time');
ylabel('Ratio of infected');

%% Plot Recovered
subplot(3,1,3);
plot(t,R, 'green', 'LineWidth', 4);
title('Local Recovered over time values at coordinate');
xlabel('time');
ylabel('Ratio of recovered');

%% Save Plot
pHeight = 3;
pWidth = 4;
set(gcf, 'PaperUnits', 'Inches', 'PaperPosition',[0 0 pWidth pHeight],...
    'PaperSize', [pHeight pWidth]);
saveas(f1, sprintf('time_series_%.2f_%.2f_%.2f.png', coord(1), coord(2), coord(3)));


end