function write2Excel(mesh, t, X, filename)

%% Declare Constants
N = numel(t); % number of steps
Nc = size(X,1); % number of locations

%% Preallocate space 

S = zeros(Nc,1); % susceptible
I = zeros(Nc,1); % infected
R = zeros(Nc,1); % recovered

 
variableNames = {'x Coordinate','y Coordinate','z Coordinate', 'Susceptible rate', 'Infected Rate', 'Recovered Rate'} ;

targetTime = 0;

xcoord = zeros(Nc, 1);
ycoord = zeros(Nc, 1);
zcoord = zeros(Nc, 1); 
% create x, y ,z arrays of the coordinates
for k = 1:Nc
    xcoord(k) = mesh(k).location(1); 
    ycoord(k) = mesh(k).location(2);
    zcoord(k) = mesh(k).location(3);
end

for i = 1:N % needs to print out more information from mesh
    
    if abs(t(i) - targetTime) <= 1
                
        S(:) = X(:,1,i); %  susceptible rate at ith step
        I(:) = X(:,2,i); % infected rate at ith step
        R(:) = X(:,3,i); % recovered rate at ith step


        T = table(xcoord,ycoord, zcoord, S,I,R, 'VariableNames', variableNames);
        nameOfSheet = sprintf('T = = %f', t(i));
        writetable(T,filename,'Sheet', nameOfSheet, 'Range', 'A1');
        
        targetTime = targetTime + 15;
    end
    
    
end





