function mesh = stlRead(fileLocation)
% stlRead takes the location a modified stl file (.txt format) is ...
%stored, reads the file, and finds the required parameters.
% Input:
% fileLocation: location of the tab delimited .txt file to be read
% Output:
% mesh: an array of structs representing the vertices. Each ...
%element has members "location" and "neighbors". "location" is a 1x3 ...
%array of x, y, z coordinates, and "neighbors" is an array of indices ...
%of the point's neighbors.

data = readcell(fileLocation, 'Delimiter', '\t'); % read in data

%% Initialize data
uniquePoints = zeros(0,3); 
mesh = [];

%% Iterate through Data
for i = 1:length(data)
    if (data(i,1) == "outerLoop")
        
        index = zeros(1,3);
        for j = 1:3
            p = cell2mat(data(i+j,2:end));
            check = ismember(uniquePoints,p, 'rows');
            if any(check) % if point is already in array, find index in uniquepoints
                index(1,j) = find(check);
            else % if not already in array, append to end of array
                uniquePoints = [uniquePoints; p];
                index(1,j) = size(uniquePoints,1);
                mesh(end+1).location = p;
            end
        end
        
                                    
        mesh(end).neighbors = []; % initialize array at end of struct
        
        
        
        mesh(index(1,1)).neighbors = union(mesh(index(1,1)).neighbors,[index(2) ,index(3)]); % append to end of neighbors array at that index
        mesh(index(1,2)).neighbors = union(mesh(index(1,2)).neighbors,[index(1) ,index(3)]);
        mesh(index(1,3)).neighbors = union(mesh(index(1,3)).neighbors,[index(1) ,index(2)]);
    end
end


end

        
   
        
        
       
            
            
        
        