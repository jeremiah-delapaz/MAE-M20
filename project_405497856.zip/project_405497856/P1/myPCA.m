function [coefforth,pcaData] = myPCA(data)
% myPCA analyzes the principal components of given COVID-19 statistical ...
%data from multiple countries - covid_countries.csv
% Inputs:
% data: A nxp matrix representing only the numerical parts of ...
%the dataset
% Outputs:
% coeffOrth: a pxp matrix whose columns are the eigenvectors ...
% corresponding to the sorted eigenvalues
% pcaData: a nxp matrix

[rows, cols] = size(data);

%% Normalize Data
mean = zeros(1,cols);
stand = zeros(1,cols); %standard deviation
xNorm = zeros(rows, cols);
for i = 1: cols
    mean(i) = sum(data(:,i)) / rows;
    stand(i) = std(data(:,i));
end

for i = 1: cols
    for j = 1: rows
        xNorm(j,i) = (data(j,i) - mean(i))./stand(i);
    end
end


%% Covariance Matrix

covX = (xNorm' * xNorm)/ (rows - 1);

%% EigenValues and Eigen Vectors

[vectors,values] = eig(covX);
values = abs(values);
values = diag(values);
[~, index] = sort(values, 'descend'); % sort eigenvalues and keep an array of the index they are sorted to
[eigenrows,~] = size(vectors);
coefforth = zeros(eigenrows, cols); % initialize coefforth matrix
for i = 1: cols
    coefforth(:,i) = vectors(:,index(i)); % places eigenvector of sorted index of the value into coefforth matrix.
end

%%

pcaData = xNorm * coefforth;

        
    
    