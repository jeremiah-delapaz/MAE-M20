%{

%}


clear all; close all; clc;

data = readtable('covid_countries.csv', 'VariableNamingRule', 'preserve' );

dataDuct = table2array(data(1:end,3:end)); % maintain only the numerical values 

[coefforth,pcaData1] = myPCA(dataDuct);

vbls = data.Properties.VariableNames;
vbls = vbls(3:end);
pcaData2D = pcaData1(:, 1:2);
biplot(coefforth(:,1:2),'Scores', pcaData2D,'Varlabels',vbls);
